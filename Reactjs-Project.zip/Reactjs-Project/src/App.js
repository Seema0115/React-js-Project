import '../node_modules/bootstrap/dist/css/bootstrap.css';
import '../node_modules/bootstrap/dist/js/bootstrap.bundle';
import React from 'react';
import './App.css';

import Navbar from './Component/Navbar';
import './Component/Navbar.css';
import CompA from './Component/CompA';
import './Component/CompA.css';
import CompB from './Component/CompB';
import './Component/CompB.css';
import CompC from './Component/CompC';
import './Component/CompC.css';
import Footer from './Component/Footer';
import './Component/Footer.css';

function App() {
  return (
    <>
      <Navbar />
      <CompA />
      <CompB />
      <CompC />
      <Footer />
    </>
  );
}

export default App;
