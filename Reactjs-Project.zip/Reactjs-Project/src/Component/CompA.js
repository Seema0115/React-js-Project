import React from "react";

function CompA(Props){
    return (
        <>
            <div className="innerHeading-wrap">
                <div className="container">
                    <h1>About Us</h1>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li>/</li>
                        <li>About Us</li>
                    </ul>
                </div>
            </div>
        </>
    )
}
export default CompA;