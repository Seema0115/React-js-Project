import React from "react";
import flightf from '../Component/images/illustration/gallery-1.jpg';
import flighta from '../Component/images/illustration/gallery-2.jpg';
import flightb from '../Component/images/illustration/gallery-3.jpg';
import flightc from '../Component/images/illustration/gallery-4.jpg';
import flightd from '../Component/images/illustration/gallery-5.jpg';
import flighte from '../Component/images/illustration/gallery-6.jpg';


function CompB(Props) {
    return(
        <>
            <section className="flight-wrap">
                <div className="container">
                    <div className="row">
                        <div className="col-12 col-md-12 col-lg-4 shadow-sm">
                            <div className="flight flightf ">
                                <img src={flightf} />
                            </div>

                            <div className="path-box">
                                <h3>
                                    <a href="#">Discovery Points</a>
                                </h3>
                                <div className="time-box">
                                    Class Time: 
                                    <span> 08:00 am - 10:00 am</span>
                                </div>
                                <p>
                                    The drive to play freely is a basic, biological drive. Lack of free play may not kill the physical body, as would lack of air, food, or water, but it kills the spirit and stunts mental growth. 
                                </p>
                            </div>
                        </div>

                        <div className="col-12 col-md-12 col-lg-4 shadow-sm">
                            <div className="flight flighta">
                                <img src={flighta} />
                            </div>

                            <div className="path-box">
                                <h3>
                                    <a href="#">Our Curriculum</a>
                                </h3>
                                <div className="time-box">
                                    Class Time: 
                                    <span> 08:00 am - 10:00 am</span>
                                </div>
                                <p>
                                    The drive to play freely is a basic, biological drive. Lack of free play may not kill the physical body, as would lack of air, food, or water, but it kills the spirit and stunts mental growth. 
                                </p>
                            </div>
                        </div>

                        <div className="col-12 col-md-12 col-lg-4 shadow-sm">
                            <div className="flight flightb ">
                                <img src={flightb} />
                            </div>

                            <div className="path-box">
                                <h3>
                                    <a href="#">Discovery Points</a>
                                </h3>
                                <div className="time-box">
                                    Class Time: 
                                    <span> 08:00 am - 10:00 am</span>
                                </div>
                                <p>
                                The drive to play freely is a basic, biological drive. Lack of free play may not kill the physical body, as would lack of air, food, or water, but it kills the spirit and stunts mental growth.  
                                </p>
                            </div>
                        </div>

                        <div className="col-12 col-md-12 col-lg-4 shadow-sm">
                            <div className="flight flightc">
                                <img src={flightc} />
                            </div>

                            <div className="path-box">
                                <h3>
                                    <a href="#">Our Curriculum</a>
                                </h3>
                                <div className="time-box">
                                    Class Time: 
                                    <span> 08:00 am - 10:00 am</span>
                                </div>
                                <p>
                                    The drive to play freely is a basic, biological drive. Lack of free play may not kill the physical body, as would lack of air, food, or water, but it kills the spirit and stunts mental growth.
                                </p>
                            </div>
                        </div>

                        <div className="col-12 col-md-12 col-lg-4 shadow-sm">
                            <div className="flight flightd">
                                <img src={flightd} />
                            </div>

                            <div className="path-box">
                                <h3>
                                    <a href="#">Discovery Points</a>
                                </h3>
                                <div className="time-box">
                                    Class Time: 
                                    <span> 08:00 am - 10:00 am</span>
                                </div>
                                <p>
                                    The drive to play freely is a basic, biological drive. Lack of free play may not kill the physical body, as would lack of air, food, or water, but it kills the spirit and stunts mental growth.
                                </p>
                            </div>
                        </div>

                        <div className="col-12 col-md-12 col-lg-4 shadow-sm">
                            <div className="flight flighte">
                                <img src={flighte} />
                            </div>

                            <div className="path-box">
                                <h3>
                                    <a href="#">Our Curriculum</a>
                                </h3>
                                <div className="time-box">
                                    Class Time: 
                                    <span> 08:00 am - 10:00 am</span>
                                </div>
                                <p>
                                    The drive to play freely is a basic, biological drive. Lack of free play may not kill the physical body, as would lack of air, food, or water, but it kills the spirit and stunts mental growth.
                                </p>
                            </div>
                        </div>

                    </div>

                </div>

            </section>
        </>
    )
}

export default CompB;