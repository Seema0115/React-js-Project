import React from "react";

function CompC(Props) {
    return(
        <>
        <section className="new-wrap">
            <div className="container">
                <div className="row">
                    <div className="col-12 col-md-12 col-lg-6">
                        <div className="title">
                            <h1>Newsletter</h1>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur.</p>
                    </div>
                    <div className="col-12 col-md-12 col-lg-6">
                        <div className="news-info">
                            <form>
                                <div className="input-group">
                                    <input className="form-control d-block" type="text" name="search" placeholder="Email Address" />
                                    
                                    <div className="form-icon"> 
                                        <i class="bi bi-envelope-fill"></i>
                                    </div>
                                </div>

                                <button className="sigup">
                                     <i class="bi bi-send-fill"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        </>
    )
}
export default CompC;