import React, {useState} from "react";
import Logo from '../Component/images/illustration/logo-kiddy.png';



function Navbar(Props) {
    const [nav, setNav] = useState('navbarMain');

    const [justify, setjustify] = useState('justifyMain');


    function setNavbar() {
        if ((nav === 'navbarMain')) {
            setNav('ToggleNavbar')
        } else {
            setNav('navbarMain');
        }
        if ((justify === 'justifyMain')) {
            setjustify('justifyMain toggle')

        } else {
            setjustify('justifyMain');
        }
    }
    return(
        <>
            <div className="topbar-wrap">
                <div className="container">
                    <div className="row">
                        <div className="col-12 col-md-6 col-lg-6">
                            <div className="address">
                            <i class="bi bi-geo-alt-fill"></i>
                            23 E. Lorem Street, Ipsum, sit 123
                            </div>
                        </div>
                        <div className="col-12 col-md-6 col-lg-6">
                            <ul className="top-right">
                                <li>
                                    <div className="followus d-none d-md-none d-lg-none">
                                        <span>Follow Us</span>
                                            <ul className="navbar nav-pills">
                                                <li className="nav-items"><a className="nav-links" href=""><i class="bi bi-facebook"></i></a></li>
                                                <li className="nav-items"><a className="nav-links" href=""><i class="bi bi-twitter"></i></a></li>
                                                <li className="nav-items"><a className="nav-links" href=""><i class="bi bi-linkedin"></i></a></li>
                                                <li className="nav-items"><a className="nav-links" href=""><i class="bi bi-instagram"></i></a></li>
                                            </ul>
                                    </div>
                                </li>
                                <li>
                                    <div className="phone">
                                        <a href=""> <i class="bi bi-telephone-fill"></i>
                                            (770) 123 4567
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
            <header className="header-wrap" role="banner">
                <div className="container">
                    <div className="row">
                        <div className="col-12 col-md-12 col-lg-4 navbar-light">
                            <div className="logo">
                                <a href="#">
                                    <img className="logo-default" src={Logo}  alt=""/>
                                </a>
                            </div>
                            <button className="navbar-toggler d-md-block d-lg-none d-xl-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-expanded="true" aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon"></span>
                            </button>
                        </div>

                        <div className="col-12 col-md-12 col-lg-8 d-sm-none d-md-none d-lg-block d-xl-block">
                            <div className="navigation-wrap">

                                <nav className="navbar navbar-expand-lg navbar-light">

                                    <a className="navbar-brand d-none" href="">Menu</a>
                                    <div id="navbarSupportedContent" className="navbar-collapse collapse show">

                                        <button className="close-toggler" type="button" data-toggle="offcanvas">
                                            <span><i class="bi bi-x-square-fill" aria-hidden="true"></i></span>
                                        </button>

                                    </div>
                                   <div className="collapse navbar-collapse">
                                    <ul className="navbar-nav mr-auto">
                                        
                                        <li className="nav-item">
                                            <a className="nav-link" href="">Home
                                            <span className="sr-only">(current)</span></a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" href="">About</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" href="">Gallery</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" href="">courses</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" href="">testinomials</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" href="">blog</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" href="">contact us</a>
                                        </li>
                                    </ul>

                                    </div>  
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
        </>
    );
}
export default Navbar;